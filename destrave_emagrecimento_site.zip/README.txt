Como usar este pacote:

1) Testar localmente:
   - Abra o arquivo index.html no seu navegador (duplo clique).
   - Ou, para testar o redirecionamento PHP, use um servidor local com PHP:
     php -S localhost:8000
     e acesse http://localhost:8000

2) Publicar online (opções rápidas):
   - GitHub Pages: crie um repositório, envie index.html e ative Pages nas configurações.
   - Netlify / Vercel: arraste a pasta para o painel (deploy grátis).
   - Hospedagem com suporte a PHP: envie index.php para a raiz para que o site redirecione automaticamente.

3) Conteúdo:
   - index.html : página estática pronta.
   - index.php  : redirecionamento automático para a página de pagamento.

Se quiser, eu posso:
 - criar um arquivo .zip pronto para enviar (já incluído aqui),
 - configurar um repositório GitHub com estes arquivos (preciso do seu token ou você faz o upload após eu fornecer os arquivos),
 - ou gerar instruções passo-a-passo para publicar no Netlify/Cloudflare Pages em menos de 2 minutos.
