<?php
// Redireciona diretamente para a página de pagamento
header('Location: https://pay.kiwify.com.br/XZN0nSl');
exit;
?>